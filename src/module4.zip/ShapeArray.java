
public class ShapeArray {
	public static void main(String args[]) {
		Sphere sphere = new Sphere (7);
		Cylinder cylinder = new Cylinder(9,12);
		Cone cone = new Cone(4,8);
		Shape[] shapeArray = new Shape[3];
		shapeArray[0] = sphere;
		shapeArray[1] = cylinder;
		shapeArray[2] = cone;
		
		for(Shape s : shapeArray) {
			System.out.println(s.toString());	
		}
	}
}
